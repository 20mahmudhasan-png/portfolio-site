// js/script.js

console.log("Portfolio site loaded successfully.");

// Contact form handler
function handleSubmit(event) {
  event.preventDefault();
  const status = document.getElementById("form-status");
  status.textContent = "Message sent successfully! (Demo only)";
  status.style.color = "green";
  event.target.reset();
  return false;
}

// Theme Toggle Logic
function toggleTheme() {
  document.body.classList.toggle("dark-mode");
  const isDark = document.body.classList.contains("dark-mode");
  localStorage.setItem("theme", isDark ? "dark" : "light");
  document.querySelector(".theme-toggle").textContent = isDark ? "☀️" : "🌙";
}

// Load saved theme on page load
window.addEventListener("load", () => {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
    document.querySelector(".theme-toggle").textContent = "☀️";
  }
});
